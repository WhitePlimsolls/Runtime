//
//  CustomGreeter.h
//  CustomgGreeter
//
//  Created by 陈泽嘉 on 16/1/22.
//  Copyright © 2016年 dibadalu. All rights reserved.
//  

#import <Foundation/Foundation.h>
#import "Greeter.h"

@interface CustomGreeter : NSObject<Greeter>//遵守Greeter协议

@end
